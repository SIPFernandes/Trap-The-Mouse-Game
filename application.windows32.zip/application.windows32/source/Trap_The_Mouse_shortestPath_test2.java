import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Trap_The_Mouse_shortestPath_test2 extends PApplet {

                                                                                                                                                                                                                                                                                                                                                                                              //Samuel Fernandes nº 41674 2017

SoundFile file;
SoundFile file2;

final int aliceblue = color(240, 248, 255);
final int antiquewhite = color(250, 235, 215);
final int aqua = color(0, 255, 255);
final int aquamarine = color(127, 255, 212);
final int azure = color(240, 255, 255);
final int beige = color(245, 245, 220);
final int bisque = color(255, 228, 196);
final int black = color(0, 0, 0);
final int blanchedalmond = color(255, 235, 205);
final int blue = color(0, 0, 255);
final int blueviolet = color(138, 43, 226);
final int brown = color(165, 42, 42);
final int burlywood = color(222, 184, 135);
final int cadetblue = color(95, 158, 160);
final int chartreuse = color(127, 255, 0);
final int chocolate = color(210, 105, 30);
final int coral = color(255, 127, 80);
final int cornflowerblue = color(100, 149, 237);
final int cornsilk = color(255, 248, 220);
final int crimson = color(220, 20, 60);
final int cyan = color(0, 255, 255);
final int darkblue = color(0, 0, 139);
final int darkcyan = color(0, 139, 139);
final int darkgoldenrod = color(184, 134, 11);
final int darkgray = color(169, 169, 169);
final int darkgreen = color(0, 100, 0);
final int darkkhaki = color(189, 183, 107);
final int darkmagenta = color(139, 0, 139);
final int darkolivegreen = color(85, 107, 47);
final int darkorange = color(255, 140, 0);
final int darkorchid = color(153, 50, 204);
final int darkred = color(139, 0, 0);
final int darksalmon = color(233, 150, 122);
final int darkseagreen = color(143, 188, 143);
final int darkslateblue = color(72, 61, 139);
final int darkslategray = color(47, 79, 79);
final int darkturquoise = color(0, 206, 209);
final int darkviolet = color(148, 0, 211);
final int deeppink = color(255, 20, 147);
final int deepskyblue = color(0, 191, 255);
final int dimgray = color(105, 105, 105);
final int dodgerblue = color(30, 144, 255);
final int firebrick = color(178, 34, 34);
final int floralwhite = color(255, 250, 240);
final int forestgreen = color(34, 139, 34);
final int fuchsia = color(255, 0, 255);
final int gainsboro = color(220, 220, 220);
final int ghostwhite = color(248, 248, 255);
final int gold = color(255, 215, 0);
final int goldenrod = color(218, 165, 32);
final int gray = color(128, 128, 128);
final int green = color(0, 128, 0);
final int greenyellow = color(173, 255, 47);
final int honeydew = color(240, 255, 240);
final int hotpink = color(255, 105, 180);
final int indianred = color(205, 92, 92);
final int indigo = color(75, 0, 130);
final int ivory = color(255, 255, 240);
final int khaki = color(240, 230, 140);
final int lavender = color(230, 230, 250);
final int lavenderblush = color(255, 240, 245);
final int lawngreen = color(124, 252, 0);
final int lemonchiffon = color(255, 250, 205);
final int lightblue = color(173, 216, 230);
final int lightcoral = color(240, 128, 128);
final int lightcyan = color(224, 255, 255);
final int lightgoldenrodyellow = color(250, 250, 210);
final int lightgray = color(211, 211, 211);
final int lightgreen = color(144, 238, 144);
final int lightpink = color(255, 182, 193);
final int lightsalmon = color(255, 160, 122);
final int lightseagreen = color(32, 178, 170);
final int lightskyblue = color(135, 206, 250);
final int lightslategray = color(119, 136, 153);
final int lightsteelblue = color(176, 196, 222);
final int lightyellow = color(255, 255, 224);
final int lime = color(0, 255, 0);
final int limegreen = color(50, 205, 50);
final int linen = color(250, 240, 230);
final int magenta = color(255, 0, 255);
final int maroon = color(128, 0, 0);
final int mediumaquamarine = color(102, 205, 170);
final int mediumblue = color(0, 0, 205);
final int mediumorchid = color(186, 85, 211);
final int mediumpurple = color(147, 112, 219);
final int mediumseagreen = color(60, 179, 113);
final int mediumslateblue = color(123, 104, 238);
final int mediumspringgreen = color(0, 250, 154);
final int mediumturquoise = color(72, 209, 204);
final int mediumvioletred = color(199, 21, 133);
final int midnightblue = color(25, 25, 112);
final int mintcream = color(245, 255, 250);
final int mistyrose = color(255, 228, 225);
final int moccasin = color(255, 228, 181);
final int navajowhite = color(255, 222, 173);
final int navy = color(0, 0, 128);
final int oldlace = color(253, 245, 230);
final int olive = color(128, 128, 0);
final int olivedrab = color(107, 142, 35);
final int orange = color(255, 165, 0);
final int orangered = color(255, 69, 0);
final int orchid = color(218, 112, 214);
final int palegoldenrod = color(238, 232, 170);
final int palegreen = color(152, 251, 152);
final int paleturquoise = color(175, 238, 238);
final int palevioletred = color(219, 112, 147);
final int papayawhip = color(255, 239, 213);
final int peachpuff = color(255, 218, 185);
final int peru = color(205, 133, 63);
final int pink = color(255, 192, 203);
final int plum = color(221, 160, 221);
final int powderblue = color(176, 224, 230);
final int purple = color(128, 0, 128);
final int red = color(255, 0, 0);
final int rosybrown = color(188, 143, 143);
final int royalblue = color(65, 105, 225);
final int saddlebrown = color(139, 69, 19);
final int salmon = color(250, 128, 114);
final int sandybrown = color(244, 164, 96);
final int seagreen = color(46, 139, 87);
final int seashell = color(255, 245, 238);
final int sienna = color(160, 82, 45);
final int silver = color(192, 192, 192);
final int skyblue = color(135, 206, 235);
final int slateblue = color(106, 90, 205);
final int slategray = color(112, 128, 144);
final int snow = color(255, 250, 250);
final int springgreen = color(0, 255, 127);
final int steelblue = color(70, 130, 180);
final int tan = color(210, 180, 140);
final int teal = color(0, 128, 128);
final int thistle = color(216, 191, 216);
final int tomato = color(255, 99, 71);
final int turquoise = color(64, 224, 208);
final int violet = color(238, 130, 238);
final int wheat = color(245, 222, 179);
final int white = color(255, 255, 255);
final int whitesmoke = color(245, 245, 245);
final int yellow = color(255, 255, 0);
final int yellowgreen = color(154, 205, 50);

final int [] HTMLColors = {
  aqua, black, blue, fuchsia, gray, 
  green, lime, maroon, navy, olive, 
  orange, purple, red, silver, teal, 
  white, yellow};

final int [] allColors = { aliceblue, antiquewhite, aqua, aquamarine, 
  azure, beige, bisque, black, blanchedalmond, blue, blueviolet, brown, 
  burlywood, cadetblue, chartreuse, chocolate, coral, cornflowerblue, 
  cornsilk, crimson, cyan, darkblue, darkcyan, darkgoldenrod, darkgray, 
  darkgreen, darkkhaki, darkmagenta, darkolivegreen, darkorange, 
  darkorchid, darkred, darksalmon, darkseagreen, darkslateblue, 
  darkslategray, darkturquoise, darkviolet, deeppink, deepskyblue, dimgray, 
  dodgerblue, firebrick, floralwhite, forestgreen, fuchsia, gainsboro, 
  ghostwhite, gold, goldenrod, gray, green, greenyellow, honeydew, hotpink, 
  indianred, indigo, ivory, khaki, lavender, lavenderblush, lawngreen, 
  lemonchiffon, lightblue, lightcoral, lightcyan, lightgoldenrodyellow, 
  lightgray, lightgreen, lightpink, lightsalmon, lightseagreen, 
  lightskyblue, lightslategray, lightsteelblue, lightyellow, lime, 
  limegreen, linen, magenta, maroon, mediumaquamarine, mediumblue, 
  mediumorchid, mediumpurple, mediumseagreen, mediumslateblue, 
  mediumspringgreen, mediumturquoise, mediumvioletred, midnightblue, 
  mintcream, mistyrose, moccasin, navajowhite, navy, oldlace, olive, 
  olivedrab, orange, orangered, orchid, palegoldenrod, palegreen, 
  paleturquoise, palevioletred, papayawhip, peachpuff, peru, pink, plum, 
  powderblue, purple, red, rosybrown, royalblue, saddlebrown, salmon, 
  sandybrown, seagreen, seashell, sienna, silver, skyblue, slateblue, 
  slategray, snow, springgreen, steelblue, tan, teal, thistle, tomato, 
  turquoise, violet, wheat, white, whitesmoke, yellow, yellowgreen };

String[] images = {"rato.jpg", "wall.jpg", "relva.jpg", "floor.jpg", "queijo.jpg"};

PImage[] images1 = new PImage[images.length];

public void loadAllImages()
{
  for (int i = 0; i < images.length; i++)
    images1[i] = loadImage(images[i]);
}

public void drawAllImages()  
{
  image(images1[0], 0, 0, myWidth, myHeight);
}

int[][] board;
int [][] boardAux;
int [][] boardAux2;

final int myRows = 9;
final int myColumns = 11;

final int side = 50;

final int myWidth = myColumns * side;
final int myHeight = myRows * side;

int windowColor = white;

int cell;
int r;
int c;
int move;
int positionX = myColumns/2;
int positionY = myRows/2;
int mouse;
int newMouse;
float x;
float y;
int[] cheeseP = {0, 10, 88, 98};
int crazy;

public void settings()
{
  size(myWidth, myHeight);
}

public void setup()
{
  loadAllImages();
  file = new SoundFile(this, "intro.mp3");
  file.play(1);
  file2 = new SoundFile(this, "block.mp3");
  drawAllImages();
  textSize(65);
  fill(darkred);
  text("Trap The Mouse", myHeight/20, myWidth/8);
  textSize(40);
  fill(darkblue);
  text("Press 'SPACE' to start", myHeight/6, myWidth/2);
  stroke(black);
  fill(white);
  rect(myHeight/6, myWidth/1.9f, 400, 120);
  textSize(30);
  fill(black);
  text("Tip:", myHeight/5.5f, myWidth/1.74f);
  textSize(20);
  text("Build walls to prevent the mouse from", myHeight/5.5f, myWidth/1.60f);
  text("getting the cheese!", myHeight/5.5f, myWidth/1.50f);
  board = new int[myRows][myColumns];
  boardAux = new int[myRows][myColumns];
  boardAux2 = new int[myRows][myColumns];
  randomParts(board, myRows, myColumns);
  int index2 = PApplet.parseInt(random(cheeseP.length));
  mouse = cheeseP[index2];
}

public void draw()
{
  if(key == ' ')
  {
    loseLine(myRows, myColumns);
    inside(myRows, myColumns);
    drawGrid();
    allDistances(board, myRows, myColumns, positionY, positionX, boardAux);
    shortestPath(myRows, myColumns, boardAux, boardAux2);
    //drawDistances(myRows, myColumns);
    //drawPath(myRows, myColumns);
    mousePosition();
    drawMouse(board, myRows, myColumns);
    drawWalls(board, myRows, myColumns);
    gameOver(myRows, myColumns);
    if (move == 2)
    {
      stroke(green);
      fill(white);
      rect(myHeight/2.5f, myWidth/3.5f, 200, 100);
      textSize(50);
      fill(green);
      text("Victory", myHeight/2.3f, myWidth/2.5f);
    }
    if (move == 3)
    {
      stroke(red);
      fill(white);
      rect(myHeight/3.5f, myWidth/3.5f, 300, 100);
      textSize(50);
      fill(red);
      text("Game Over", myHeight/3.2f, myWidth/2.5f);
    }
  }
}

public void mouseClicked()
{
  if(key == ' ')
  {
    x = mouseX;
    y = mouseY;
    int z = getCell();
    r = z/myColumns;
    c = z%myColumns;
    if (move == 0 && board[r][c] == 0 && r > 0 && r < myRows-1 && c > 0 && c < myColumns-1)
    {
      file2.play();
      board[r][c] = 1;
      move = 1;
    }
    if (move == 1)
    {
      mouseMove();
      /*if (crazy == 1)
        findPath(board);*/
    }
  //println(positionX);
  //println(positionY);
  }
}

public int getCell()
{
  int column = PApplet.parseInt (x)/side;
  int row = PApplet.parseInt(y)/side; 
  cell = column + row*myColumns;
  println(cell);
  return cell;
}

public void mousePosition()
{
  if (board[positionY][positionX] == 0)
    board[positionY][positionX] = 2;
}

public void drawGrid()
{
  stroke(black);
  for (int i = 0; i <= myColumns; i++)
    line(i*side, 0, i*side, myHeight);
  for (int i = 0; i <= myRows; i++)
    line(0, i*side, myWidth, i*side);
}

public void drawWalls(int[][] m, int rows, int columns)
{
  for (int i = 0; i < rows; i++)
    for (int j = 0; j< columns; j++)
      if (m[i][j] == 1)
        image(images1[1], j*side, i*side, side, side);
}

public void drawMouse(int[][] m, int rows, int columns)
{
  for (int i = 0; i < rows; i++)
    for (int j = 0; j< columns; j++)
      if (m[i][j] == 2)
        image(images1[0], j*side+2, i*side+2, side-4, side-4);
}

public void ints_shuffle(int[] a)
{
  int n = a.length;
  for (int i = 0; i < n-1; i++)
    ints_exchange(a, i, i+PApplet.parseInt(random(n-1-i)));
}

public void ints_exchange(int[] a, int x, int y)
{
  int m = a[x];
  a[x] = a[y];
  a[y] = m;
}

public int countEmpty(int[][] m, int rows, int columns)
{
  int result = 0;
  for (int i = 0; i < rows; i++)
    for (int j = 0; j < columns; j++)
      if (m[i][j] == 0)
        result++;
  return result;
}

public int [] freeSpaces(int[][]m, int rows, int columns)
{
  int a[] = new int[countEmpty(m, rows, columns)];
  int result = 0;
  for (int i = 0; i < rows; i++)
    for (int j = 0; j < columns; j++)
      if (m[i][j] == 0 && i*columns + j != 49)
        a[result++] = i*columns + j;
  return a;
}

public void randomParts(int[][] m, int rows, int columns)
{
  int[] a = freeSpaces(m, rows, columns);
  ints_shuffle(a);
  int result = 0;
  while (result < 0)
  {
    for (int i = 0; i < rows; i++)
      for (int j = 0; j < columns; j++)
        if (a[result] == i*columns + j)
          m[i][j] = 1;
    result++;
  }
}

public void findPath(int[][] m)
{
  if (m[positionY+1][positionX] == 0)
  {
    board[positionY][positionX] = 0;
    positionY++;
    board[positionY][positionX] = 2;
    move = 0;
  } 
  else if (m[positionY][positionX+1] == 0)
  {
    board[positionY][positionX] = 0;
    positionX++;
    board[positionY][positionX] = 2;
    move = 0;
  } 
  else if (m[positionY][positionX-1] == 0)
  {
    board[positionY][positionX] = 0;
    positionX--;
    board[positionY][positionX] = 2;
    move = 0;
  } 
  else if (m[positionY-1][positionX] == 0)
  {
    board[positionY][positionX] = 0;
    positionY--;
    board[positionY][positionX] = 2;
    move = 0;
  } 
  else
    move = 2;
}

public void gameOver(int rows, int columns)
{
  if (positionY == rows-1 || positionX == columns-1 || positionY == 0 || positionX == 0)
    move = 3;    
}

public void loseLine(int rows, int columns)
{
  for (int i = 0; i < rows; i++)
    for (int j = 0; j < columns; j++)
      if (i == rows-1 || i == 0 || j == columns-1 || j == 0)
        image(images1[4], j*side, i*side, side, side);
}

public void inside(int rows, int columns)
{
  for (int i = 1; i < rows-1; i++)
    for (int j = 1; j < columns-1; j++)
        image(images1[3], j*side, i*side, side, side);
}

public void drawDistances(int rows, int columns)
{
  for(int i = 0; i < rows; i++)
    for(int j = 0; j < columns; j++)
    {
      textSize(10);
      fill(black);
      text(boardAux[i][j], j*side+side/2, i*side+side/2, 50);
    }
}

public void fullBoardAux(int[][] d, int rows, int columns)
{
  for(int i = 0; i < rows; i++)
    for(int j = 0; j < columns; j++)
      d[i][j] = -1;
}

public int findArround(int[][] m, int rows, int columns, int r, int c, int x, int[][] d)
{
  int result = 0;
  if(r+1 < rows && d[r+1][c] == -1 && m[r+1][c] == 0)
  {
    d[r+1][c] = x;
    result++;
  }
  if(r-1 >= 0 && d[r-1][c] == -1 && m[r-1][c] == 0)
  {
    d[r-1][c] = x;
    result++;
  }
  if(c+1 < columns && d[r][c+1] == -1 && m[r][c+1] == 0)
  {
    d[r][c+1] = x;
    result++;
  }
  if(c-1 >= 0 && d[r][c-1] == -1 && m[r][c-1] == 0)
  {
    d[r][c-1] = x;
    result++;
  }
  return result;
}

public void cicloX(int[][] m, int rows, int columns, int r, int c, int[][] d)
{
  int x = 0;
  d[r][c] = x;
  int result = 1;
  while(result != 0)
    {
      result = 0;
      for (int i = 0; i < rows; i++)
        for (int j = 0; j < columns; j++)
          if (d[i][j] == x)
            result += findArround(m, rows, columns, i, j, x+1, d);
      x++;
    }
}

public void allDistances(int[][] m, int rows, int columns, int r, int c, int[][] d)
{
  fullBoardAux(d, rows, columns);
  cicloX(m, rows, columns, r, c, d);        
}

public void drawPath(int rows, int columns)
{
  for(int i = 0; i < rows; i++)
    for(int j = 0; j < columns; j++)
    {
      fill(yellow);
      if(boardAux2[i][j] == 1)
      ellipse(j*side+side/2, i*side+side/2, side/2, side/2);
    }
}

public void fullBoardAux2(int[][] p, int rows, int columns)
{
  for (int i=0; i < rows; i++)
    for (int j=0; j< columns; j++)
      p[i][j] = 0;
}

public void findPath(int[][] d, int[][] p, int mouse2,int distance, int rows, int columns)
{
  int r = mouse2/columns;
  int c = mouse2%columns;
  if(r+1 < rows && d[r+1][c] == distance-1)
  {
    p[r+1][c] = 1;
    newMouse = (r+1) * columns + c;
  }
  else if(r-1 >= 0 && d[r-1][c] == distance-1)
  {
    p[r-1][c] = 1;
    newMouse = (r-1) * columns + c;
  }
  else if(c+1 < columns && d[r][c+1] == distance-1)
  {
    p[r][c+1] = 1;
    newMouse = r * columns + (c+1);
  }
  else if(c-1 >= 0 && d[r][c-1] == distance-1)
  {
    p[r][c-1] = 1;
    newMouse = r * columns + (c-1);
  }
}

public void shortestPath(int rows, int columns, int [][] d, int[][] p)
{
  fullBoardAux2(boardAux2, myRows, myColumns);
  newMouse = mouse;
  int r = newMouse/columns;
  int c = newMouse%columns;
  int distance = d[r][c];
  if(d[r][c] != -1)
  {
    p[r][c] = 1;
    while(distance > 0)
    {
      findPath(d, p, newMouse, distance, rows, columns);
      distance--;
    }
  }
  else{
    //crazy = 1;
    move = 2;
  }
}

public void mouseMove()
{
  if(boardAux2[positionY+1][positionX] == 1 && board[positionY+1][positionX] == 0)
  {
    board[positionY][positionX] = 0;
    positionY++;
    board[positionY][positionX] = 2;
    move = 0;
  }
  else if(boardAux2[positionY-1][positionX] == 1 && board[positionY-1][positionX] == 0)
  {
    board[positionY][positionX] = 0;
    positionY--;
    board[positionY][positionX] = 2;
    move = 0;
  }
  else if(boardAux2[positionY][positionX+1] == 1 && board[positionY][positionX+1] == 0)
  {
    board[positionY][positionX] = 0;
    positionX++;
    board[positionY][positionX] = 2;
    move = 0;
  }
  else if(boardAux2[positionY][positionX-1] == 1 && board[positionY][positionX-1] == 0)
  {
    board[positionY][positionX] = 0;
    positionX--;
    board[positionY][positionX] = 2;
    move = 0;
  }
  else if(crazy == 0)
    findPath(board);
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Trap_The_Mouse_shortestPath_test2" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
